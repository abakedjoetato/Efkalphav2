#!/bin/bash
# Simple script to run health checks on the Discord bot

echo "============================="
echo "  Discord Bot Health Check"
echo "============================="
echo ""

python manage.py "$@"