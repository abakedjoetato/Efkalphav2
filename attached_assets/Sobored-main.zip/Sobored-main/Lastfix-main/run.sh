#!/bin/bash

# Run the Discord bot with optimized settings for Replit
echo "Starting Discord Bot on Replit..."
python replit_run.py