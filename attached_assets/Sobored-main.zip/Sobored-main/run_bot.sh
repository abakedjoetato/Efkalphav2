#!/bin/bash
python run.py --force --skip-validation
