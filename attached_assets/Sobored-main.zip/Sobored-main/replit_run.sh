#!/bin/bash

echo "Starting Discord bot in Replit environment..."

# Make sure the script can be executed
chmod +x run.sh

# Use our Replit-specific entry point
python replit_run.py